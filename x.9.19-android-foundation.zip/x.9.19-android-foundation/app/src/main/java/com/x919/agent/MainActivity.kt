package com.x919.agent

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val AppBackground = Color(0xFF0B1020)
private val Panel = Color(0xFF151D31)
private val Accent = Color(0xFF8B7CFF)
private val Muted = Color(0xFF9AA6BF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Accent,
                    secondary = Color(0xFF55C6B2),
                    background = AppBackground,
                    surface = Panel,
                    onPrimary = Color.White,
                    onBackground = Color(0xFFF4F5FA),
                    onSurface = Color(0xFFF4F5FA)
                )
            ) {
                X919App()
            }
        }
    }
}

private data class ChatMessage(val text: String, val fromUser: Boolean)

@Composable
private fun X919App() {
    var selectedTab by rememberSaveable { mutableStateOf(0) }
    val messages = remember {
        mutableStateListOf(
            ChatMessage(
                "Selamat datang di x.9.19. Fondasi aplikasi sudah siap. Hubungkan provider AI pada tahap berikutnya untuk mulai mengobrol.",
                false
            )
        )
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = AppBackground
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            AppHeader()
            Box(modifier = Modifier.weight(1f)) {
                when (selectedTab) {
                    0 -> ChatScreen(messages = messages)
                    1 -> ProvidersScreen()
                    else -> SettingsScreen()
                }
            }
            NavigationBar(containerColor = Panel) {
                NavigationBarItem(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    icon = { Text("✦", fontSize = 19.sp) },
                    label = { Text("Chat") }
                )
                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    icon = { Text("◈", fontSize = 19.sp) },
                    label = { Text("Providers") }
                )
                NavigationBarItem(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    icon = { Text("⚙", fontSize = 19.sp) },
                    label = { Text("Settings") }
                )
            }
        }
    }
}

@Composable
private fun AppHeader() {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Panel)
            .padding(horizontal = 20.dp, vertical = 17.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column {
            Text(
                "x.9.19",
                fontSize = 23.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
            Text("PERSONAL AI AGENT", fontSize = 10.sp, color = Muted, letterSpacing = 1.5.sp)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .background(Color(0xFF3B315F), CircleShape)
                    .padding(horizontal = 11.dp, vertical = 7.dp)
            ) {
                Text("FOUNDATION", color = Color(0xFFD8D0FF), fontSize = 9.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun ChatScreen(messages: MutableList<ChatMessage>) {
    var draft by rememberSaveable { mutableStateOf("") }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("Percakapan", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("AI workspace · Provider belum tersambung", color = Muted, fontSize = 12.sp)
        Spacer(Modifier.height(14.dp))

        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF292344)),
            shape = RoundedCornerShape(14.dp)
        ) {
            Text(
                "Mode fondasi: tampilan dan penyimpanan sesi sedang disiapkan. Balasan AI aktif setelah adapter provider dibangun.",
                modifier = Modifier.padding(13.dp),
                color = Color(0xFFE3DEFF),
                fontSize = 12.sp
            )
        }

        Spacer(Modifier.height(12.dp))
        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(messages) { message ->
                MessageBubble(message)
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = draft,
                onValueChange = { draft = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Tulis pesan...", color = Muted) },
                maxLines = 4,
                shape = RoundedCornerShape(18.dp)
            )
            Button(
                onClick = {
                    val submitted = draft.trim()
                    if (submitted.isNotEmpty()) {
                        messages.add(ChatMessage(submitted, true))
                        messages.add(
                            ChatMessage(
                                "Pesan tersimpan di tampilan lokal. AI belum dihubungkan pada Tahap 1; konektor provider akan dibuat pada tahap berikutnya.",
                                false
                            )
                        )
                        draft = ""
                    }
                },
                enabled = draft.isNotBlank(),
                shape = RoundedCornerShape(16.dp),
                contentPadding = ButtonDefaults.ContentPadding
            ) {
                Text("Kirim")
            }
        }
        Spacer(Modifier.height(5.dp))
        Text(
            "Voice, AI response, dan agent tools akan ditambahkan pada tahap berikutnya.",
            color = Muted,
            fontSize = 10.sp
        )
    }
}

@Composable
private fun MessageBubble(message: ChatMessage) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (message.fromUser) Arrangement.End else Arrangement.Start
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(0.88f),
            colors = CardDefaults.cardColors(
                containerColor = if (message.fromUser) Color(0xFF39305F) else Panel
            ),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(Modifier.padding(13.dp)) {
                Text(
                    if (message.fromUser) "KAMU" else "X.9.19",
                    color = if (message.fromUser) Color(0xFFD9D0FF) else Color(0xFF75D8C4),
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(5.dp))
                Text(message.text, color = Color(0xFFF4F5FA), fontSize = 14.sp)
            }
        }
    }
}

@Composable
private fun ProvidersScreen() {
    val providers = listOf(
        "Google Gemini" to "Prioritas integrasi pertama",
        "ChatGPT" to "Adapter website / sesi akun",
        "Claude" to "Adapter website / sesi akun",
        "Qwen" to "Adapter website / sesi akun",
        "Kimi" to "Adapter website / sesi akun",
        "Grok" to "Adapter website / sesi akun",
        "GLM / Z.ai" to "Adapter website / sesi akun",
        "Meta AI" to "Adapter website / sesi akun"
    )

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("AI Providers", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("Pilih dan kelola konektor AI", color = Muted, fontSize = 12.sp)
        Spacer(Modifier.height(14.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp)) {
            items(providers) { provider ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = Panel),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .background(Color(0xFF302A50), RoundedCornerShape(10.dp))
                                .padding(11.dp)
                        ) {
                            Text(provider.first.take(1), color = Color(0xFFD8D0FF), fontWeight = FontWeight.Bold)
                        }
                        Column(Modifier.weight(1f).padding(start = 12.dp)) {
                            Text(provider.first, fontWeight = FontWeight.SemiBold)
                            Text(provider.second, color = Muted, fontSize = 11.sp)
                        }
                        Text("BELUM AKTIF", color = Color(0xFFFFC66D), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingsScreen() {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Settings", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("Pengaturan aplikasi x.9.19", color = Muted, fontSize = 12.sp)
        Spacer(Modifier.height(16.dp))
        SettingRow("Application", "x.9.19 · Android")
        SettingRow("Build version", "0.1.0 · Foundation")
        SettingRow("Minimum Android", "Android 10 (API 29)")
        SettingRow("AI API key", "Tidak digunakan pada fondasi")
        SettingRow("Voice", "Male · Bahasa Indonesia (tahap berikutnya)")
        SettingRow("MCP", "Belum dikonfigurasi")
        Spacer(Modifier.height(12.dp))
        Text(
            "Privasi: kredensial provider tidak dikumpulkan oleh versi fondasi ini. Integrasi login akan dirancang per provider pada tahap berikutnya.",
            color = Muted,
            fontSize = 12.sp
        )
    }
}

@Composable
private fun SettingRow(title: String, value: String) {
    Card(
        modifier = Modifier.fillMaxWidth().padding(bottom = 9.dp),
        colors = CardDefaults.cardColors(containerColor = Panel),
        shape = RoundedCornerShape(13.dp)
    ) {
        Column(Modifier.padding(14.dp)) {
            Text(title, color = Muted, fontSize = 11.sp)
            Spacer(Modifier.height(4.dp))
            Text(value, fontWeight = FontWeight.Medium, fontSize = 14.sp)
        }
    }
}
