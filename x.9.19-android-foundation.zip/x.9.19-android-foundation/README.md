# x.9.19 — Android AI Agent Foundation

Native Android starter project for the x.9.19 application.

## Current scope

This is **Stage 1 (Foundation)**:
- Kotlin + Jetpack Compose
- Android minimum API 29 (Android 10)
- Chat, Providers, and Settings screens
- GitHub Actions cloud build workflow

AI provider adapters, MCP execution, speech recognition, and text-to-speech are intentionally not active yet. The UI must not be mistaken for a working AI connection.

## Build APK in GitHub Actions

1. Create a GitHub account if needed.
2. Create a new repository named `x.9.19` (public or private).
3. Upload the contents of this project to the repository root. Keep the `.github/workflows/android-build.yml` file and its folder structure.
4. Open the repository's **Actions** tab.
5. Select **x.9.19 Android Cloud Build**.
6. Press **Run workflow**. A push to the `main` branch also triggers a build.
7. Wait for the workflow to finish successfully.
8. Open the completed workflow run and download the artifact named `x.9.19-debug-apk`.
9. Extract the downloaded ZIP and install the APK on the Android phone. If Android asks, allow installation from the browser or file manager used to open the APK.

## Important notes

- The debug APK application ID has the suffix `.debug`.
- This is a development build, not a signed Play Store release.
- The first build needs internet access to download Gradle and Android dependencies.
- GitHub Actions usage is subject to GitHub account plan limits and usage policies.
- No AI API key is included or required by this foundation project.
- Do not upload passwords, cookies, browser session exports, or private credentials to the repository.

## Project versions

- Android Gradle Plugin: 8.7.3
- Gradle: 8.9
- Kotlin: 2.0.21
- JDK: 17
- Compile SDK: 35
- Minimum SDK: 29
